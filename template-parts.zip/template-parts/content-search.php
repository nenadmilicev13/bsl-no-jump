<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nmtheme
 */

?>

<div class="search">
	<h2 class="page-title">Here goes content for search</h2>
</div>