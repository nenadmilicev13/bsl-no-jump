<?php
/**
 * Template name: FinSource
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package  nmtheme
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
            <div class="banner-head__image">
                <div class="wrapper">
                    <div class="banner-head__image-wrap">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/demo/FinSourceBanner.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="single-work">
                <div class="wrapper wrapper--sm">
                    <div class="single-work__intro">
                        <p>FinSource Accounting is a tailored accounting and bookkeeping family-owned and operated firm which understands the unique challenges of running a business and a family. Founded by a corporate alumna of Deloitte and BNP Paribas, with over 15 years of experience in the financial industry.</p>
                        <div class="single-work__intro-flex">
                            <div class="single-work__intro-flex-item-left">
                                <ul>
                                    <li>Brand Discovery</li>
                                    <li>Website Design</li>
                                    <li>Development</li>
                                </ul>
                            </div>
                            <div class="single-work__intro-flex-item-right">
                                <p>Since the company was at its early stages, the client asked us to design a logo and a temporary one-page website that would expand and develop over time, as the business grew. Because FinSource Accounting makes “complex financials simple”, our task was to create their visual identity accordingly.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-left-img-right">
                <div class="wrapper wrapper--sm">
                    <div class="text-left-img-right__container">
                        <div class="text-left-img-right__content">
                            <h3>We were asked to design a simple but memorable logo that will differentiate them from competitors and a user-friendly website that their future customers can easily navigate.</h3>
                        </div>
                        <div class="text-left-img-right__image">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/demo/finSource1.png" alt="">
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="image-sec">
                <div class="wrapper">
                    <div class="image-sec__logo">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/demo/finSource-logo.svg" alt="">
                    </div>
                    <div class="image-sec__full-img">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/demo/finSource-logo.svg" alt="">
                    </div>
                </div>
            </div>
            
		</main><!-- #main -->
		<div class="cursor">
			<div class="cursor-media">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/demo/view.svg" alt="" id="view"></img>
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/demo/drag.svg" alt=""id="drag"></img>
			</div>	
		</div>
        <script src="https://unpkg.com/regenerator-runtime@0.13.1/runtime.js"></script>
	</div><!-- #primary -->
<?php
get_footer();

//////////////////////////////////////////////////////////////////////////
